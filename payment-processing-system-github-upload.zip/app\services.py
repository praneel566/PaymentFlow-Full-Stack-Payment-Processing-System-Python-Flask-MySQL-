from decimal import Decimal, InvalidOperation

from app.extensions import db
from app.gateway import PaymentGateway
from app.models import (
    Payment,
    PaymentMethod,
    PaymentStatus,
    Refund,
    RefundStatus,
    Transaction,
    TransactionStatus,
)


gateway = PaymentGateway()


class ValidationError(Exception):
    pass


class NotFoundError(Exception):
    pass


def parse_amount(value, field="amount"):
    try:
        amount = Decimal(str(value)).quantize(Decimal("0.01"))
    except (InvalidOperation, TypeError):
        raise ValidationError(f"{field} must be a valid decimal amount.") from None

    if amount <= 0:
        raise ValidationError(f"{field} must be greater than zero.")
    return amount


def create_payment(payload):
    required = ["amount", "currency", "payment_method", "customer_id", "merchant_id"]
    missing = [field for field in required if payload.get(field) in (None, "")]
    if missing:
        raise ValidationError(f"Missing required fields: {', '.join(missing)}.")

    currency = str(payload["currency"]).upper()
    if len(currency) != 3:
        raise ValidationError("currency must be a 3-letter ISO code.")

    try:
        method = PaymentMethod(payload["payment_method"])
    except ValueError:
        allowed = ", ".join(method.value for method in PaymentMethod)
        raise ValidationError(f"payment_method must be one of: {allowed}.") from None

    idempotency_key = payload.get("idempotency_key")
    if idempotency_key:
        existing = Payment.query.filter_by(idempotency_key=idempotency_key).first()
        if existing:
            return existing

    payment = Payment(
        amount=parse_amount(payload["amount"]),
        currency=currency,
        payment_method=method,
        customer_id=str(payload["customer_id"]),
        merchant_id=str(payload["merchant_id"]),
        idempotency_key=idempotency_key,
        metadata_json=payload.get("metadata") or {},
        status=PaymentStatus.PROCESSING,
    )
    db.session.add(payment)
    db.session.flush()

    _attempt_charge(payment, simulate_failure=bool(payload.get("simulate_failure")))
    db.session.commit()
    return payment


def retry_payment(payment_id):
    payment = get_payment(payment_id)
    if payment.status != PaymentStatus.FAILED:
        raise ValidationError("Only failed payments can be retried.")

    payment.status = PaymentStatus.PROCESSING
    payment.failure_reason = None
    _attempt_charge(payment, simulate_failure=False)
    db.session.commit()
    return payment


def create_refund(payment_id, payload):
    payment = get_payment(payment_id)
    if payment.status not in (PaymentStatus.SUCCEEDED, PaymentStatus.PARTIALLY_REFUNDED):
        raise ValidationError("Only succeeded or partially refunded payments can be refunded.")

    amount = parse_amount(payload["amount"], "amount") if payload.get("amount") is not None else payment.refundable_amount
    if amount > payment.refundable_amount:
        raise ValidationError("Refund amount exceeds refundable payment balance.")

    result = gateway.refund(payment, amount)
    refund = Refund(
        payment=payment,
        amount=amount,
        reason=payload.get("reason"),
        status=RefundStatus.SUCCEEDED if result.succeeded else RefundStatus.FAILED,
        gateway_reference=result.reference,
    )
    db.session.add(refund)
    db.session.flush()

    if refund.status == RefundStatus.SUCCEEDED:
        payment.status = (
            PaymentStatus.REFUNDED
            if payment.refundable_amount == Decimal("0.00")
            else PaymentStatus.PARTIALLY_REFUNDED
        )

    db.session.commit()
    return refund


def get_payment(payment_id):
    payment = db.session.get(Payment, payment_id)
    if not payment:
        raise NotFoundError("Payment not found.")
    return payment


def _attempt_charge(payment, simulate_failure=False):
    transaction = Transaction(payment=payment, status=TransactionStatus.PROCESSING)
    db.session.add(transaction)
    db.session.flush()

    result = gateway.charge(payment, simulate_failure=simulate_failure)
    if result.succeeded:
        transaction.status = TransactionStatus.SUCCEEDED
        transaction.gateway_reference = result.reference
        payment.status = PaymentStatus.SUCCEEDED
        payment.failure_reason = None
    else:
        transaction.status = TransactionStatus.FAILED
        transaction.error_code = result.error_code
        transaction.error_message = result.error_message
        payment.status = PaymentStatus.FAILED
        payment.failure_reason = result.error_message
