from datetime import datetime, timezone
from decimal import Decimal
from enum import Enum
from uuid import uuid4

from sqlalchemy import Numeric

from app.extensions import db


def utc_now():
    return datetime.now(timezone.utc)


def new_id(prefix):
    return f"{prefix}_{uuid4().hex}"


class PaymentStatus(str, Enum):
    PENDING = "pending"
    PROCESSING = "processing"
    SUCCEEDED = "succeeded"
    FAILED = "failed"
    REFUNDED = "refunded"
    PARTIALLY_REFUNDED = "partially_refunded"


class TransactionStatus(str, Enum):
    PROCESSING = "processing"
    SUCCEEDED = "succeeded"
    FAILED = "failed"


class RefundStatus(str, Enum):
    SUCCEEDED = "succeeded"
    FAILED = "failed"


class PaymentMethod(str, Enum):
    CARD = "card"
    BANK_TRANSFER = "bank_transfer"
    WALLET = "wallet"


class Payment(db.Model):
    __tablename__ = "payments"

    id = db.Column(db.String(48), primary_key=True, default=lambda: new_id("pay"))
    amount = db.Column(Numeric(12, 2), nullable=False)
    currency = db.Column(db.String(3), nullable=False)
    status = db.Column(db.Enum(PaymentStatus), nullable=False, default=PaymentStatus.PENDING)
    payment_method = db.Column(db.Enum(PaymentMethod), nullable=False)
    customer_id = db.Column(db.String(80), nullable=False, index=True)
    merchant_id = db.Column(db.String(80), nullable=False, index=True)
    idempotency_key = db.Column(db.String(120), unique=True, nullable=True)
    failure_reason = db.Column(db.String(255), nullable=True)
    metadata_json = db.Column(db.JSON, nullable=False, default=dict)
    created_at = db.Column(db.DateTime(timezone=True), nullable=False, default=utc_now)
    updated_at = db.Column(db.DateTime(timezone=True), nullable=False, default=utc_now, onupdate=utc_now)

    transactions = db.relationship(
        "Transaction",
        back_populates="payment",
        cascade="all, delete-orphan",
        lazy="select",
    )
    refunds = db.relationship(
        "Refund",
        back_populates="payment",
        cascade="all, delete-orphan",
        lazy="select",
    )

    @property
    def refunded_amount(self):
        return sum((refund.amount for refund in self.refunds if refund.status == RefundStatus.SUCCEEDED), Decimal("0.00"))

    @property
    def refundable_amount(self):
        return self.amount - self.refunded_amount


class Transaction(db.Model):
    __tablename__ = "transactions"

    id = db.Column(db.String(48), primary_key=True, default=lambda: new_id("txn"))
    payment_id = db.Column(db.String(48), db.ForeignKey("payments.id"), nullable=False, index=True)
    status = db.Column(db.Enum(TransactionStatus), nullable=False, default=TransactionStatus.PROCESSING)
    gateway_reference = db.Column(db.String(120), nullable=True)
    error_code = db.Column(db.String(80), nullable=True)
    error_message = db.Column(db.String(255), nullable=True)
    created_at = db.Column(db.DateTime(timezone=True), nullable=False, default=utc_now)

    payment = db.relationship("Payment", back_populates="transactions")


class Refund(db.Model):
    __tablename__ = "refunds"

    id = db.Column(db.String(48), primary_key=True, default=lambda: new_id("rfnd"))
    payment_id = db.Column(db.String(48), db.ForeignKey("payments.id"), nullable=False, index=True)
    amount = db.Column(Numeric(12, 2), nullable=False)
    reason = db.Column(db.String(255), nullable=True)
    status = db.Column(db.Enum(RefundStatus), nullable=False, default=RefundStatus.SUCCEEDED)
    gateway_reference = db.Column(db.String(120), nullable=True)
    created_at = db.Column(db.DateTime(timezone=True), nullable=False, default=utc_now)

    payment = db.relationship("Payment", back_populates="refunds")
