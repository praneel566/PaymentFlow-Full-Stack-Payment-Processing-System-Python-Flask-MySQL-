import pytest

from app import create_app
from app.extensions import db


class TestConfig:
    SQLALCHEMY_DATABASE_URI = "sqlite:///:memory:"
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    TESTING = True
    PAYMENT_GATEWAY_FAILURE_RATE = 0


@pytest.fixture()
def client():
    app = create_app(TestConfig)
    with app.app_context():
        db.create_all()
    yield app.test_client()


def payment_payload(**overrides):
    payload = {
        "amount": "100.00",
        "currency": "USD",
        "payment_method": "card",
        "customer_id": "cust_123",
        "merchant_id": "merchant_123",
    }
    payload.update(overrides)
    return payload


def test_create_payment_succeeds(client):
    response = client.post("/api/payments", json=payment_payload())

    assert response.status_code == 201
    body = response.get_json()
    assert body["status"] == "succeeded"
    assert body["amount"] == "100.00"
    assert body["transactions"][0]["status"] == "succeeded"


def test_frontend_shell_loads(client):
    response = client.get("/")

    assert response.status_code == 200
    assert b"Payment Processing Console" in response.data


def test_idempotency_key_returns_existing_payment(client):
    payload = payment_payload(idempotency_key="order-1")

    first = client.post("/api/payments", json=payload).get_json()
    second = client.post("/api/payments", json=payload).get_json()

    assert first["id"] == second["id"]


def test_failed_payment_can_be_retried(client):
    failed = client.post("/api/payments", json=payment_payload(simulate_failure=True)).get_json()

    retry_response = client.post(f"/api/payments/{failed['id']}/retry")

    assert retry_response.status_code == 200
    body = retry_response.get_json()
    assert body["status"] == "succeeded"
    assert len(body["transactions"]) == 2


def test_refund_updates_payment_status(client):
    payment = client.post("/api/payments", json=payment_payload()).get_json()

    response = client.post(f"/api/payments/{payment['id']}/refunds", json={"amount": "40.00"})

    assert response.status_code == 201
    refund = response.get_json()
    assert refund["amount"] == "40.00"

    payment_response = client.get(f"/api/payments/{payment['id']}").get_json()
    assert payment_response["status"] == "partially_refunded"
    assert payment_response["refunded_amount"] == "40.00"
    assert payment_response["refundable_amount"] == "60.00"
