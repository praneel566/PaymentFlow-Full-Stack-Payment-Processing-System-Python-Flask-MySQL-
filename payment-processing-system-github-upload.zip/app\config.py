import os

from dotenv import load_dotenv


load_dotenv()


class Config:
    SQLALCHEMY_DATABASE_URI = os.getenv(
        "DATABASE_URL",
        "mysql+pymysql://payments_user:payments_password@127.0.0.1:3306/payments_db",
    )
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    SQLALCHEMY_ENGINE_OPTIONS = {
        "pool_pre_ping": True,
        "pool_recycle": 280,
    }
    PAYMENT_GATEWAY_FAILURE_RATE = float(os.getenv("PAYMENT_GATEWAY_FAILURE_RATE", "0"))
