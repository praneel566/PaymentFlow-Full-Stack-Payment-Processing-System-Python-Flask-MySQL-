from flask import Blueprint, jsonify, request

from app.extensions import db
from app.models import Payment, Refund, Transaction
from app.schemas import payment_to_dict, refund_to_dict, transaction_to_dict
from app.services import NotFoundError, ValidationError, create_payment, create_refund, retry_payment


api = Blueprint("api", __name__, url_prefix="/api")


@api.errorhandler(ValidationError)
def handle_validation_error(error):
    return jsonify({"error": str(error)}), 400


@api.errorhandler(NotFoundError)
def handle_not_found(error):
    return jsonify({"error": str(error)}), 404


@api.post("/payments")
def post_payment():
    payment = create_payment(request.get_json(silent=True) or {})
    return jsonify(payment_to_dict(payment)), 201


@api.get("/payments")
def list_payments():
    query = Payment.query.order_by(Payment.created_at.desc())

    if request.args.get("status"):
        query = query.filter(Payment.status == request.args["status"])
    if request.args.get("customer_id"):
        query = query.filter(Payment.customer_id == request.args["customer_id"])
    if request.args.get("merchant_id"):
        query = query.filter(Payment.merchant_id == request.args["merchant_id"])

    payments = query.limit(100).all()
    return jsonify({"data": [payment_to_dict(payment, include_children=False) for payment in payments]})


@api.get("/payments/<payment_id>")
def get_payment_detail(payment_id):
    payment = db.session.get(Payment, payment_id)
    if not payment:
        raise NotFoundError("Payment not found.")
    return jsonify(payment_to_dict(payment))


@api.post("/payments/<payment_id>/retry")
def post_payment_retry(payment_id):
    payment = retry_payment(payment_id)
    return jsonify(payment_to_dict(payment))


@api.post("/payments/<payment_id>/refunds")
def post_refund(payment_id):
    refund = create_refund(payment_id, request.get_json(silent=True) or {})
    return jsonify(refund_to_dict(refund)), 201


@api.get("/refunds")
def list_refunds():
    query = Refund.query.order_by(Refund.created_at.desc())
    if request.args.get("payment_id"):
        query = query.filter(Refund.payment_id == request.args["payment_id"])

    refunds = query.limit(100).all()
    return jsonify({"data": [refund_to_dict(refund) for refund in refunds]})


@api.get("/transactions")
def list_transactions():
    query = Transaction.query.order_by(Transaction.created_at.desc())
    if request.args.get("payment_id"):
        query = query.filter(Transaction.payment_id == request.args["payment_id"])

    transactions = query.limit(100).all()
    return jsonify({"data": [transaction_to_dict(transaction) for transaction in transactions]})
