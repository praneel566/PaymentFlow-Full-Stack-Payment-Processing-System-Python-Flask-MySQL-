# Payment Processing System

A full-stack Flask + MySQL payment processing system with a REST API and an HTML/CSS/JavaScript operations console.

## Features

- Create and process card/bank/wallet payments
- Track transaction attempts with status history
- Simulate gateway failures for testing failure handling
- Retry failed payments
- Create partial or full refunds
- Query payments, transactions, and refunds
- MySQL-ready schema through SQLAlchemy migrations at app startup
- Browser dashboard for creating payments, filtering the ledger, retrying failures, and issuing refunds

## Quick Start

1. Create an environment file:

```powershell
Copy-Item .env.example .env
```

2. Start MySQL:

```powershell
docker compose up -d mysql
```

3. Install dependencies:

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
```

4. Run the API:

```powershell
flask --app app:create_app run --debug
```

The API runs at `http://127.0.0.1:5000`.

Open `http://127.0.0.1:5000` in a browser to use the frontend console.

## Run Without Docker

If Docker is not installed, use SQLite for local development:

```powershell
Copy-Item .env.example .env
Set-Content .env "FLASK_ENV=development`nDATABASE_URL=sqlite:///dev.db`nPAYMENT_GATEWAY_FAILURE_RATE=0"
flask --app app:create_app run --debug
```

## GitHub Upload Notes

Commit the source files, `README.md`, `.env.example`, `requirements.txt`, and `docker-compose.yml`.

Do not commit `.env`, virtual environments, caches, logs, or local database files. These are excluded by `.gitignore`.

## API

### Health

```http
GET /health
```

### Create Payment

```http
POST /api/payments
Content-Type: application/json

{
  "amount": 1499.99,
  "currency": "USD",
  "payment_method": "card",
  "customer_id": "cust_123",
  "merchant_id": "merchant_001",
  "idempotency_key": "order-1001",
  "metadata": {
    "order_id": "1001"
  }
}
```

Optional testing flag:

```json
{
  "simulate_failure": true
}
```

### List Payments

```http
GET /api/payments?status=succeeded&customer_id=cust_123
```

### Get Payment

```http
GET /api/payments/{payment_id}
```

### Retry Failed Payment

```http
POST /api/payments/{payment_id}/retry
```

### Refund Payment

```http
POST /api/payments/{payment_id}/refunds
Content-Type: application/json

{
  "amount": 500.00,
  "reason": "requested_by_customer"
}
```

Omit `amount` to refund the remaining refundable balance.

### List Refunds

```http
GET /api/refunds
```

### Get Transactions

```http
GET /api/transactions?payment_id={payment_id}
```

## Statuses

Payments: `pending`, `processing`, `succeeded`, `failed`, `refunded`, `partially_refunded`

Transactions: `processing`, `succeeded`, `failed`

Refunds: `succeeded`, `failed`

## Tests

```powershell
pytest
```

Tests use SQLite in memory, while normal app execution uses the MySQL `DATABASE_URL`.
