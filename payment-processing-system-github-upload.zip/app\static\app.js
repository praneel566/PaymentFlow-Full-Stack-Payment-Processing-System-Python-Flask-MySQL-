const state = {
  payments: [],
  transactions: [],
  refunds: [],
};

const money = new Intl.NumberFormat("en-US", {
  style: "currency",
  currency: "USD",
});

const elements = {
  healthStatus: document.querySelector("#healthStatus"),
  refreshButton: document.querySelector("#refreshButton"),
  paymentForm: document.querySelector("#paymentForm"),
  formStatus: document.querySelector("#formStatus"),
  statusFilter: document.querySelector("#statusFilter"),
  paymentList: document.querySelector("#paymentList"),
  transactionTable: document.querySelector("#transactionTable"),
  refundTable: document.querySelector("#refundTable"),
  metricVolume: document.querySelector("#metricVolume"),
  metricSucceeded: document.querySelector("#metricSucceeded"),
  metricFailed: document.querySelector("#metricFailed"),
  metricRefunded: document.querySelector("#metricRefunded"),
  paymentTemplate: document.querySelector("#paymentTemplate"),
};

async function api(path, options = {}) {
  const response = await fetch(path, {
    headers: { "Content-Type": "application/json" },
    ...options,
  });

  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    throw new Error(data.error || "Request failed");
  }
  return data;
}

async function checkHealth() {
  try {
    await api("/health");
    elements.healthStatus.textContent = "Online";
  } catch (error) {
    elements.healthStatus.textContent = "Offline";
  }
}

async function loadAll() {
  const status = elements.statusFilter.value;
  const paymentPath = status ? `/api/payments?status=${encodeURIComponent(status)}` : "/api/payments";

  const [payments, transactions, refunds] = await Promise.all([
    api(paymentPath),
    api("/api/transactions"),
    api("/api/refunds"),
  ]);

  state.payments = payments.data || [];
  state.transactions = transactions.data || [];
  state.refunds = refunds.data || [];
  render();
}

function render() {
  renderMetrics();
  renderPayments();
  renderTransactions();
  renderRefunds();
}

function renderMetrics() {
  const visiblePayments = state.payments;
  const volume = visiblePayments
    .filter((payment) => ["succeeded", "partially_refunded", "refunded"].includes(payment.status))
    .reduce((sum, payment) => sum + Number(payment.amount), 0);
  const refunded = visiblePayments.reduce((sum, payment) => sum + Number(payment.refunded_amount), 0);

  elements.metricVolume.textContent = money.format(volume);
  elements.metricSucceeded.textContent = visiblePayments.filter((payment) => payment.status === "succeeded").length;
  elements.metricFailed.textContent = visiblePayments.filter((payment) => payment.status === "failed").length;
  elements.metricRefunded.textContent = money.format(refunded);
}

function renderPayments() {
  elements.paymentList.innerHTML = "";

  if (!state.payments.length) {
    elements.paymentList.innerHTML = '<div class="empty-state">No payments found.</div>';
    return;
  }

  for (const payment of state.payments) {
    const node = elements.paymentTemplate.content.firstElementChild.cloneNode(true);
    node.querySelector(".payment-id").textContent = payment.id;
    node.querySelector(".payment-meta").textContent = `${payment.customer_id} to ${payment.merchant_id} via ${payment.payment_method}`;
    node.querySelector(".payment-amount").textContent = `${payment.currency} ${Number(payment.amount).toFixed(2)}`;

    const badge = node.querySelector(".status-badge");
    badge.textContent = payment.status.replaceAll("_", " ");
    badge.classList.add(payment.status);

    const actions = node.querySelector(".payment-actions");
    if (payment.status === "failed") {
      actions.appendChild(actionButton("Retry", () => retryPayment(payment.id)));
    }
    if (["succeeded", "partially_refunded"].includes(payment.status) && Number(payment.refundable_amount) > 0) {
      actions.appendChild(actionButton("Refund", () => refundPayment(payment)));
    }
    actions.appendChild(actionButton("Details", () => showPaymentDetails(payment.id)));

    elements.paymentList.appendChild(node);
  }
}

function renderTransactions() {
  elements.transactionTable.innerHTML = tableRows(
    state.transactions,
    (transaction) => `
      <tr>
        <td>${shortId(transaction.id)}</td>
        <td>${shortId(transaction.payment_id)}</td>
        <td>${transaction.status}</td>
        <td>${transaction.gateway_reference || transaction.error_code || "-"}</td>
      </tr>
    `,
    4,
  );
}

function renderRefunds() {
  elements.refundTable.innerHTML = tableRows(
    state.refunds,
    (refund) => `
      <tr>
        <td>${shortId(refund.id)}</td>
        <td>${shortId(refund.payment_id)}</td>
        <td>${Number(refund.amount).toFixed(2)}</td>
        <td>${refund.status}</td>
      </tr>
    `,
    4,
  );
}

function tableRows(items, rowRenderer, columns) {
  if (!items.length) {
    return `<tr><td colspan="${columns}">No records found.</td></tr>`;
  }
  return items.map(rowRenderer).join("");
}

function actionButton(label, handler) {
  const button = document.createElement("button");
  button.className = "action-button";
  button.type = "button";
  button.textContent = label;
  button.addEventListener("click", handler);
  return button;
}

async function createPayment(event) {
  event.preventDefault();
  setFormStatus("Processing");

  const formData = new FormData(elements.paymentForm);
  const payload = {
    amount: formData.get("amount"),
    currency: String(formData.get("currency")).toUpperCase(),
    payment_method: formData.get("payment_method"),
    customer_id: formData.get("customer_id"),
    merchant_id: formData.get("merchant_id"),
    idempotency_key: formData.get("idempotency_key") || undefined,
    simulate_failure: formData.has("simulate_failure"),
    metadata: {
      order_id: formData.get("order_id") || undefined,
    },
  };

  try {
    await api("/api/payments", {
      method: "POST",
      body: JSON.stringify(payload),
    });
    setFormStatus("Payment submitted");
    elements.paymentForm.querySelector('[name="idempotency_key"]').value = "";
    await loadAll();
  } catch (error) {
    setFormStatus(error.message);
  }
}

async function retryPayment(paymentId) {
  await api(`/api/payments/${paymentId}/retry`, { method: "POST" });
  await loadAll();
}

async function refundPayment(payment) {
  const amount = window.prompt("Refund amount", payment.refundable_amount);
  if (!amount) {
    return;
  }

  await api(`/api/payments/${payment.id}/refunds`, {
    method: "POST",
    body: JSON.stringify({ amount }),
  });
  await loadAll();
}

async function showPaymentDetails(paymentId) {
  const payment = await api(`/api/payments/${paymentId}`);
  setFormStatus(`${payment.id}: ${payment.status}, refundable ${payment.currency} ${payment.refundable_amount}`);
}

function setFormStatus(message) {
  elements.formStatus.textContent = message;
}

function shortId(value) {
  return value ? value.slice(0, 10) : "-";
}

elements.paymentForm.addEventListener("submit", createPayment);
elements.refreshButton.addEventListener("click", loadAll);
elements.statusFilter.addEventListener("change", loadAll);

checkHealth();
loadAll().catch((error) => setFormStatus(error.message));
