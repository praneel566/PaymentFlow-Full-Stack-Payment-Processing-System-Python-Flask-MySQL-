import random

from flask import current_app


class GatewayResult:
    def __init__(self, succeeded, reference=None, error_code=None, error_message=None):
        self.succeeded = succeeded
        self.reference = reference
        self.error_code = error_code
        self.error_message = error_message


class PaymentGateway:
    def charge(self, payment, simulate_failure=False):
        failure_rate = current_app.config.get("PAYMENT_GATEWAY_FAILURE_RATE", 0)
        should_fail = simulate_failure or random.random() < failure_rate

        if should_fail:
            return GatewayResult(
                succeeded=False,
                error_code="gateway_declined",
                error_message="Payment was declined by the payment gateway.",
            )

        return GatewayResult(
            succeeded=True,
            reference=f"gw_{payment.id[-12:]}",
        )

    def refund(self, payment, amount):
        return GatewayResult(
            succeeded=True,
            reference=f"gw_refund_{payment.id[-12:]}_{str(amount).replace('.', '')}",
        )
