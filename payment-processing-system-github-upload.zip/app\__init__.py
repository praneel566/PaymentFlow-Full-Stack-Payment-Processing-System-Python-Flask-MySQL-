from flask import Flask, send_from_directory

from app.config import Config
from app.extensions import db
from app.routes import api


def create_app(config_object=Config):
    app = Flask(__name__, static_folder="static", static_url_path="/static")
    app.config.from_object(config_object)

    db.init_app(app)
    app.register_blueprint(api)

    @app.get("/health")
    def health():
        return {"status": "ok"}

    @app.get("/")
    def index():
        return send_from_directory(app.static_folder, "index.html")

    with app.app_context():
        db.create_all()

    return app
