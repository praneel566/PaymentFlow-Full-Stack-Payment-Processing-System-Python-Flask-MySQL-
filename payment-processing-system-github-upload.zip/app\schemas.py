def money(value):
    return f"{value:.2f}"


def transaction_to_dict(transaction):
    return {
        "id": transaction.id,
        "payment_id": transaction.payment_id,
        "status": transaction.status.value,
        "gateway_reference": transaction.gateway_reference,
        "error_code": transaction.error_code,
        "error_message": transaction.error_message,
        "created_at": transaction.created_at.isoformat(),
    }


def refund_to_dict(refund):
    return {
        "id": refund.id,
        "payment_id": refund.payment_id,
        "amount": money(refund.amount),
        "reason": refund.reason,
        "status": refund.status.value,
        "gateway_reference": refund.gateway_reference,
        "created_at": refund.created_at.isoformat(),
    }


def payment_to_dict(payment, include_children=True):
    data = {
        "id": payment.id,
        "amount": money(payment.amount),
        "currency": payment.currency,
        "status": payment.status.value,
        "payment_method": payment.payment_method.value,
        "customer_id": payment.customer_id,
        "merchant_id": payment.merchant_id,
        "idempotency_key": payment.idempotency_key,
        "failure_reason": payment.failure_reason,
        "refunded_amount": money(payment.refunded_amount),
        "refundable_amount": money(payment.refundable_amount),
        "metadata": payment.metadata_json,
        "created_at": payment.created_at.isoformat(),
        "updated_at": payment.updated_at.isoformat(),
    }
    if include_children:
        data["transactions"] = [transaction_to_dict(item) for item in payment.transactions]
        data["refunds"] = [refund_to_dict(item) for item in payment.refunds]
    return data
